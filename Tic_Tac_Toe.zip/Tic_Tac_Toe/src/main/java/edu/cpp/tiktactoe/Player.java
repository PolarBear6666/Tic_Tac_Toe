package edu.cpp.tiktactoe;

public abstract class Player {
    protected final Mark mark;

    public Player(Mark mark) {
        this.mark = mark;
    }

    public Mark getMark() {
        return mark;
    }

    // Each subclass must define how to choose its next move
    public abstract Move nextMove(Board board);
}