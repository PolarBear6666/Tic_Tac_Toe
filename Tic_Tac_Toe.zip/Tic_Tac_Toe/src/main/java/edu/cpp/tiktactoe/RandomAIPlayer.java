package edu.cpp.tiktactoe;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RandomAIPlayer extends Player {

    private final Random random = new Random();

    public RandomAIPlayer(Mark mark) {
        super(mark);
    }

    @Override
    public Move nextMove(Board board) {
        List<Move> availableMoves = new ArrayList<>();

        // Scan the board for empty cells
        for (int r = 0; r < board.getSize(); r++) {
            for (int c = 0; c < board.getSize(); c++) {
                if (board.getCell(r, c) == Mark.EMPTY) {
                    availableMoves.add(new Move(r, c, mark));
                }
            }
        }

        // Pick one at random
        if (availableMoves.isEmpty()) {
            throw new IllegalStateException("No moves left!");
        }

        return availableMoves.get(random.nextInt(availableMoves.size()));
    }
}