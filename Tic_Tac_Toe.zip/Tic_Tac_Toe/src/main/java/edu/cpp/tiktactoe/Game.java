package edu.cpp.tiktactoe;

import java.util.Optional;

public class Game {
    private final Board board;
    private final Player player1;
    private final Player player2;
    private Player currentPlayer;

    public Game(Board board, Player player1, Player player2) {
        this.board = board;
        this.player1 = player1;
        this.player2 = player2;
        this.currentPlayer = player1; // X usually starts
    }

    public void run() {
        while (true) {
            System.out.println(board);  // Display current board
            Move move = currentPlayer.nextMove(board);
            board.place(move);

            // Check for a winner
            Optional<Mark> winner = board.winner();
            if (winner.isPresent()) {
                System.out.println(board);
                System.out.println("Winner: " + winner.get());
                break;
            }

            // Check for draw
            if (board.isFull()) {
                System.out.println(board);
                System.out.println("It's a draw!");
                break;
            }

            // Switch players
            currentPlayer = (currentPlayer == player1) ? player2 : player1;
        }
    }
}