package edu.cpp.tiktactoe;

import java.util.Optional;

public class Board {
    private final int size;
    private final Mark[][] grid;

    public Board(int size) {
        this.size = size;
        grid = new Mark[size][size];
        reset(); // fill grid with EMPTY
    }

    public Board() {
        this(3); // default 3x3 board
    }

    public void reset() {
        for (int r = 0; r < size; r++) {
            for (int c = 0; c < size; c++) {
                grid[r][c] = Mark.EMPTY;
            }
        }
    }

    public Mark getCell(int r, int c) {
        validate(r, c);
        return grid[r][c];
    }

    public boolean isFull() {
        for (int r = 0; r < size; r++) {
            for (int c = 0; c < size; c++) {
                if (grid[r][c] == Mark.EMPTY) {
                    return false;
                }
            }
        }
        return true;
    }

    public void place(Move mv) {
        int r = mv.getRow();
        int c = mv.getCol();
        validate(r, c);
        if (grid[r][c] != Mark.EMPTY) {
            throw new IllegalArgumentException("Cell already occupied!");
        }
        grid[r][c] = mv.getMark();
    }

    public Optional<Mark> winner() {
        // TODO: implement logic to check rows, cols, and diagonals
        return Optional.empty();
    }

    private void validate(int r, int c) {
        if (r < 0 || r >= size || c < 0 || c >= size) {
            throw new IllegalArgumentException("Invalid row/column");
        }
    }

    public int getSize() {
        return size;
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int r = 0; r < size; r++) {
            for (int c = 0; c < size; c++) {
                sb.append(grid[r][c] == Mark.EMPTY ? "-" : grid[r][c]);
                sb.append(" ");
            }
            sb.append("\n");
        }
        return sb.toString();
    }
}

