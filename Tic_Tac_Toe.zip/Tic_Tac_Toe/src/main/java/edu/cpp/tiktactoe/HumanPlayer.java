package edu.cpp.tiktactoe;

import java.util.Scanner;

public class HumanPlayer extends Player {

    private final Scanner scanner;

    public HumanPlayer(Mark mark) {
        super(mark);
        scanner = new Scanner(System.in);
    }

    @Override
    public Move nextMove(Board board) {
        while (true) {
            System.out.print("Enter row and column (0-based, e.g. 0 2): ");
            int row = scanner.nextInt();
            int col = scanner.nextInt();
            Move mv = new Move(row, col, mark);

            try {
                board.getCell(row, col); // validate bounds
                return mv;
            } catch (Exception e) {
                System.out.println("Invalid input: " + e.getMessage());
            }
        }
    }
}