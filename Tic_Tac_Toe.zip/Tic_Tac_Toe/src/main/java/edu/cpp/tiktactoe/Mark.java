package edu.cpp.tiktactoe;

public enum Mark {
    X, O, EMPTY
}