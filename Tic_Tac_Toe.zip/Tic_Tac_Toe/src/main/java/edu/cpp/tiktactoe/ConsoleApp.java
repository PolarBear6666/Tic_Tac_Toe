package edu.cpp.tiktactoe;

public class ConsoleApp {

    public static void main(String[] args) {
        // Welcome message
        System.out.println("Welcome to Tic-Tac-Toe!");

        // Create the board (default 3x3)
        Board board = new Board();

        // Create players
        Player human = new HumanPlayer(Mark.X); // human player uses X
        Player ai = new RandomAIPlayer(Mark.O); // AI player uses O

        // Create and start the game
        Game game = new Game(board, human, ai);
        game.run();

        // Game finished message
        System.out.println("Game over! Thanks for playing.");
    }
}